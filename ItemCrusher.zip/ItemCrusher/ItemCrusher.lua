-- ItemCrusher.lua (bootstrap)
local ADDON = ...
ItemCrusherDB = ItemCrusherDB or {}

ItemCrusher = {
  addon = ADDON,
  db = ItemCrusherDB,
  L = {},
}